# Cambios aplicados a Tormentar

## 1. ¿Las alertas eran reales? No.

`app/(tabs)/index.tsx` y `app/(tabs)/map.tsx` mostraban un array fijo
`DEMO_ALERTS` hardcodeado en el código (3 alertas de ejemplo: leve,
moderada, severa), sin relación con el clima real ni con la ubicación
del usuario. El servicio real (`lib/services/weatherService.ts`, que
consulta la API "One Call 3.0" de OpenWeatherMap) y el hook de
ubicación (`hooks/useLocation.ts`) ya existían en el repo, pero nunca
se usaban en ninguna pantalla. Tampoco había ninguna API key
configurada (no existe archivo `.env`).

**Solución:** ahora ambas pantallas usan el hook nuevo `hooks/useAlerts.ts`,
que pide la ubicación real del dispositivo y consulta OpenWeatherMap de
verdad. Si falta la API key, la app lo dice explícitamente en pantalla
en vez de mostrar datos falsos.

## 2. Sensibilidad única en toda la app

Antes había DOS almacenamientos de preferencias completamente
independientes y desincronizados:
- `settings.tsx` guardaba `notificationsEnabled/soundEnabled/vibrationEnabled/updateInterval`
  bajo la clave `tormentar_settings`.
- `index.tsx` guardaba por separado un único `minSeverity` bajo la
  clave `tormentar_min_severity`.

Cambiar algo en Configuración no afectaba lo que se mostraba en
Inicio, y viceversa.

**Solución:** se creó `hooks/useAlertPreferences.ts`, una única fuente
de verdad (una sola clave de almacenamiento + caché en memoria
compartido) que usan Inicio, Mapa y Configuración. Cambiar la
sensibilidad en cualquier pantalla se refleja al instante en las
demás.

## 3. Filtro por elección del usuario: leve / moderada / fuerte

El filtro anterior era un "mínimo" de un solo valor (radio buttons).
Ahora es una selección múltiple e independiente: el usuario puede
elegir cualquier combinación de niveles (por ejemplo, recibir solo
"leve" y "fuerte" mientras ignora "moderada"). Esto se aplica tanto a
lo que se muestra en pantalla como a qué alertas disparan una
notificación push.

## 4. Otros arreglos

- Las notificaciones ahora respetan de verdad los toggles de "Sonido"
  y "Vibración" de Configuración (antes se ignoraban y siempre sonaba,
  sin importar lo que el usuario eligiera).
- Se agregó `hasApiKey()` en el servicio de clima y un aviso visible en
  Inicio/Mapa cuando falta configurar `EXPO_PUBLIC_OPENWEATHER_API_KEY`.
- Se agregó `.env.example` documentando esa variable.
- Se eliminó un botón "Buscar" en Configuración que no tenía ninguna
  acción asociada (dead code).
- Las notificaciones solo se disparan para alertas *nuevas* (no se
  vuelve a notificar una alerta ya vista) y solo para los niveles que
  el usuario tiene habilitados.

## Archivos nuevos
- `hooks/useAlertPreferences.ts`
- `hooks/useAlerts.ts`
- `.env.example`

## Archivos modificados
- `app/(tabs)/index.tsx`
- `app/(tabs)/map.tsx`
- `app/(tabs)/settings.tsx`
- `hooks/useWeatherNotifications.ts`
- `lib/services/weatherService.ts`

## Pendiente (fuera del alcance de este cambio)
- La API de OpenWeatherMap "One Call 3.0" requiere una API key con el
  plan que incluye alertas (tiene un nivel gratuito limitado). Hace
  falta cargar `EXPO_PUBLIC_OPENWEATHER_API_KEY` para que las alertas
  reales funcionen en producción.
- La búsqueda de ciudad por nombre en Configuración quedó como
  pendiente (requiere geocodificación); se dejó el aviso explícito en
  vez de un botón que no hacía nada.
